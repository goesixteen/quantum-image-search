Magic Arena · crowded festival
Artwork by David Revoy / Pepper&Carrot, CC BY 4.0. Display crop from Episode 21 page 3.
The object-only copy is transparent outside curated object silhouettes.
Whole registered objects are grouped by floor((alphaBottom-1)/16); no horizontal image slices cut through them. Each band uses its maximum member bottom. Lower target feet draw in front; equal or higher feet behind.
Band PNGs and masks are full 512x512; individual objects are cropped with registered positions. See each registrations.json for hashes and anchors.
Curated masks are approximate and do not segment every person or object.
