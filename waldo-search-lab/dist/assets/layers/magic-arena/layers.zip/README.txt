Magic Arena · crowded festival
Artwork by David Revoy / Pepper&Carrot, CC BY 4.0. Display crop from Episode 21 page 3.
Each cropped PNG is registered by registrations.json into the512px background. Bottom anchors use alpha>32. Lower target feet draw in front; equal or higher feet behind. Curated silhouette boundaries are approximate.
