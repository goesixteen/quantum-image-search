Original Festival
Original AI-generated festival artwork · retained for the frozen QNN benchmark
Each cropped PNG is registered by registrations.json into the512px background. Bottom anchors use alpha>32. Lower target feet draw in front; equal or higher feet behind. Curated silhouette boundaries are approximate.
